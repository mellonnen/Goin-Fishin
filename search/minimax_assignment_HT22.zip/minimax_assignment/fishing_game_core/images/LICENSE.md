# Authors of the images used in this game
All images were found in The Noun Project. The use of them was free given that proper credit was given to the authors. In this file, the credit is presented.

- boat1.png and boat2.png by Vectors Market
- crab1.png and crab2.png by myiconfinder
- hook.png by Andy Mc, ID
- fish0.png by Nook Fulloption
- fish1.png by Line Icons Pro, Hyderabad
- fish2.png by Line Icons Pro, Hyderabad
- fish3.png by Tatina Vazest
- fish4.png by Made x Made, AU
- fish5.png by Arief Sugiyanto, ID
- fish6.png by Wahyuntitle
- rock.png by Kate Maldjian, US
- seaweed1.png by Vladimir Belochkin, US
- seaweed2.png by Graham Jefferson, US
- seaweed3.png and seaweed4.png by Made by Made, AU
- seagulls.png by Abdo
- star.png previously available in Noun project

All images colored by Romina Arriaza Barriga
